#pragma once

namespace control_panel {

void ApplyTheme(int theme_index);
void Render();

}  // namespace control_panel
