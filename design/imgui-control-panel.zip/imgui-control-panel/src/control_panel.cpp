#include "control_panel.h"

#include <algorithm>
#include <array>
#include <string>

#include "imgui.h"

namespace control_panel {
namespace {

enum class Tab { Aimbot, Visuals, Loot, Scripts };

struct State {
  Tab tab = Tab::Aimbot;
  int theme = 0;
  bool nav_collapsed = false;
  bool silent_loot = false;
  bool always_sprint = false;
  bool desync_fire = false;
  bool perfect_physical_state = true;
  bool lag_switch = true;
  bool extended = true;
  bool no_effects = true;
  bool no_visor = true;
  bool duck_peek_assist = false;
  bool enable_assist = false;
  bool force_body_aimbot = false;
  int target_section = 0;
  int inventory_modifier = 0;
  int accuracy_stop = 0;
  int quick_stop = 0;
  int weapon_modifier = 0;
  float multiplier = 150.0f;
  float extended_lean = 0.5f;
  float delay = 20.0f;
  float penetration = 0.5f;
  float stomach_hitbox = 100.0f;
  float penetration_chance = 40.0f;
  std::array<bool, 6> visuals{true, true, false, false, true, false};
  std::array<bool, 6> loot{true, false, true, true, false, true};
  std::array<bool, 6> scripts{false, true, false, true, false, false};
  float visuals_range = 65.0f;
  float loot_range = 55.0f;
  float script_delay = 25.0f;
};

State state;
constexpr const char* kThemes[] = {"Amber Dark", "Graphite", "Light", "Crimson"};

ImVec4 Color(unsigned int hex) {
  return ImVec4(
      static_cast<float>((hex >> 24) & 0xff) / 255.0f,
      static_cast<float>((hex >> 16) & 0xff) / 255.0f,
      static_cast<float>((hex >> 8) & 0xff) / 255.0f,
      static_cast<float>(hex & 0xff) / 255.0f);
}

void DrawRowLabel(const char* label) {
  ImGui::AlignTextToFramePadding();
  ImGui::TextUnformatted(label);
  ImGui::TableNextColumn();
  ImGui::SetNextItemWidth(-1.0f);
}

void CheckRow(const char* label, bool* value) {
  ImGui::TableNextRow(0, 34.0f);
  ImGui::TableNextColumn();
  DrawRowLabel(label);
  const float size = ImGui::GetFrameHeight();
  ImGui::SetCursorPosX(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - size);
  ImGui::Checkbox((std::string("##") + label).c_str(), value);
}

void ComboRow(const char* label, int* value, const char* const items[], int count) {
  ImGui::TableNextRow(0, 34.0f);
  ImGui::TableNextColumn();
  DrawRowLabel(label);
  ImGui::Combo((std::string("##") + label).c_str(), value, items, count);
}

void SliderRow(const char* label, float* value, float min, float max, const char* format) {
  ImGui::TableNextRow(0, 34.0f);
  ImGui::TableNextColumn();
  DrawRowLabel(label);
  ImGui::SliderFloat((std::string("##") + label).c_str(), value, min, max, format);
}

bool BeginSettingsTable(const char* id) {
  return ImGui::BeginTable(id, 2, ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp);
}

void DrawAimbotColumnOne() {
  static const char* targets[] = {"Chest to crosshair", "Head", "Closest target"};
  static const char* modifiers[] = {"None", "Enabled"};
  static const char* stops[] = {"No assist", "Enabled"};
  static const char* quick_stops[] = {"None", "On key", "Automatic"};
  if (!BeginSettingsTable("aim_left")) return;
  ImGui::TableSetupColumn("Setting", ImGuiTableColumnFlags_WidthStretch, 1.25f);
  ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthStretch, 1.0f);
  CheckRow("Silent loot", &state.silent_loot);
  CheckRow("Always sprint", &state.always_sprint);
  ComboRow("Target section", &state.target_section, targets, IM_ARRAYSIZE(targets));
  ComboRow("Inventory modifiers", &state.inventory_modifier, modifiers, IM_ARRAYSIZE(modifiers));
  CheckRow("Desync fire", &state.desync_fire);
  CheckRow("Perfect physical state", &state.perfect_physical_state);
  SliderRow("Multiplier", &state.multiplier, 0.0f, 300.0f, "%.0f");
  SliderRow("Extended lean", &state.extended_lean, 0.0f, 1.0f, "%.2f");
  ComboRow("Accuracy boost stop", &state.accuracy_stop, stops, IM_ARRAYSIZE(stops));
  CheckRow("Enable assist", &state.enable_assist);
  CheckRow("Force body aimbot", &state.force_body_aimbot);
  ComboRow("Quick stop in match", &state.quick_stop, quick_stops, IM_ARRAYSIZE(quick_stops));
  ImGui::EndTable();
}

void DrawAimbotColumnTwo() {
  static const char* weapons[] = {"No spread", "Default", "Recoil only"};
  if (!BeginSettingsTable("aim_right")) return;
  ImGui::TableSetupColumn("Setting", ImGuiTableColumnFlags_WidthStretch, 1.25f);
  ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthStretch, 1.0f);
  ComboRow("Weapon modifiers", &state.weapon_modifier, weapons, IM_ARRAYSIZE(weapons));
  CheckRow("Lag switch", &state.lag_switch);
  CheckRow("Extended", &state.extended);
  SliderRow("Delay", &state.delay, 0.0f, 150.0f, "%.0f ms");
  CheckRow("No effects", &state.no_effects);
  CheckRow("No visor", &state.no_visor);
  SliderRow("Penetration power", &state.penetration, 0.0f, 1.0f, "%.2f");
  SliderRow("Stomach hitbox scale", &state.stomach_hitbox, 0.0f, 100.0f, "%.0f%%");
  CheckRow("Duck peek assist", &state.duck_peek_assist);
  SliderRow("Penetration lean chance", &state.penetration_chance, 0.0f, 100.0f, "%.0f%%");
  ImGui::EndTable();
}

void DrawAimbot() {
  if (ImGui::BeginTable("aim_columns", 2, ImGuiTableFlags_SizingStretchSame)) {
    ImGui::TableNextColumn();
    DrawAimbotColumnOne();
    ImGui::TableNextColumn();
    DrawAimbotColumnTwo();
    ImGui::EndTable();
  }
}

void DrawGeneric(const char* title, const char* const labels[6], std::array<bool, 6>& values, float* range, const char* range_label) {
  ImGui::TextColored(ImGui::GetStyleColorVec4(ImGuiCol_CheckMark), "%s", title);
  ImGui::Separator();
  if (!BeginSettingsTable(title)) return;
  ImGui::TableSetupColumn("Setting", ImGuiTableColumnFlags_WidthStretch, 1.2f);
  ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthStretch, 1.0f);
  for (int i = 0; i < 6; ++i) CheckRow(labels[i], &values[static_cast<std::size_t>(i)]);
  SliderRow(range_label, range, 0.0f, 100.0f, "%.0f%%");
  ImGui::EndTable();
}

void DrawContent() {
  static const char* visuals[] = {"Player outlines", "Distance labels", "Item highlights", "Field of view", "Night contrast", "Radar overlay"};
  static const char* loot[] = {"Rare items", "Containers", "Quest objects", "Weapon crates", "Show distance", "Show values"};
  static const char* scripts[] = {"Auto reload", "Quick swap", "Movement assist", "Key bindings", "Safety checks", "Auto profile"};
  switch (state.tab) {
    case Tab::Aimbot: DrawAimbot(); break;
    case Tab::Visuals: DrawGeneric("Visual modifiers", visuals, state.visuals, &state.visuals_range, "Render distance"); break;
    case Tab::Loot: DrawGeneric("Loot filters", loot, state.loot, &state.loot_range, "Distance limit"); break;
    case Tab::Scripts: DrawGeneric("Script controls", scripts, state.scripts, &state.script_delay, "Safety delay"); break;
  }
}

bool NavButton(const char* icon, const char* label, Tab tab, float width) {
  const bool active = state.tab == tab;
  if (active) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_HeaderActive));
  const std::string text = state.nav_collapsed ? icon : std::string(icon) + "\n" + label;
  const bool clicked = ImGui::Button(text.c_str(), ImVec2(width, state.nav_collapsed ? 48.0f : 90.0f));
  if (active) ImGui::PopStyleColor();
  if (clicked) state.tab = tab;
  return clicked;
}

}  // namespace

void ApplyTheme(int theme_index) {
  state.theme = std::clamp(theme_index, 0, 3);
  ImGuiStyle& style = ImGui::GetStyle();
  style = ImGuiStyle();
  style.WindowRounding = 8.0f;
  style.ChildRounding = 6.0f;
  style.FrameRounding = 3.0f;
  style.PopupRounding = 4.0f;
  style.ScrollbarRounding = 4.0f;
  style.TabRounding = 3.0f;
  style.WindowPadding = ImVec2(14.0f, 14.0f);
  style.FramePadding = ImVec2(8.0f, 6.0f);
  style.ItemSpacing = ImVec2(8.0f, 7.0f);
  style.CellPadding = ImVec2(8.0f, 5.0f);
  style.WindowBorderSize = 1.0f;
  style.ChildBorderSize = 1.0f;
  style.FrameBorderSize = 1.0f;

  ImVec4* c = style.Colors;
  const bool light = state.theme == 2;
  const ImVec4 bg = light ? Color(0xECEAE4FF) : (state.theme == 1 ? Color(0x15181CFF) : Color(0x171512FF));
  const ImVec4 panel = light ? Color(0xF8F7F2FF) : (state.theme == 1 ? Color(0x20242AFF) : Color(0x211F1BFF));
  const ImVec4 frame = light ? Color(0xD9D6CEFF) : (state.theme == 1 ? Color(0x2B3037FF) : Color(0x2C2923FF));
  const ImVec4 text = light ? Color(0x25282CFF) : Color(0xD4D0C7FF);
  const ImVec4 muted = light ? Color(0x6E7277FF) : Color(0x85817AFF);
  const ImVec4 accent = state.theme == 3 ? Color(0xE05252FF) : (state.theme == 1 ? Color(0x68A9C9FF) : (light ? Color(0xB06C1DFF) : Color(0xD6A63EFF)));
  const ImVec4 accent_hover = state.theme == 3 ? Color(0xF16A65FF) : (state.theme == 1 ? Color(0x7BBCD9FF) : (light ? Color(0xC47A22FF) : Color(0xE5B74DFF)));
  const ImVec4 border = light ? Color(0xB9B6AFFF) : Color(0x3A3834FF);

  c[ImGuiCol_Text] = text;
  c[ImGuiCol_TextDisabled] = muted;
  c[ImGuiCol_WindowBg] = bg;
  c[ImGuiCol_ChildBg] = panel;
  c[ImGuiCol_PopupBg] = panel;
  c[ImGuiCol_Border] = border;
  c[ImGuiCol_BorderShadow] = Color(0x00000000);
  c[ImGuiCol_FrameBg] = frame;
  c[ImGuiCol_FrameBgHovered] = Color(light ? 0xCAC6BCFF : 0x36322BFF);
  c[ImGuiCol_FrameBgActive] = Color(light ? 0xBFB9ACFF : 0x403A30FF);
  c[ImGuiCol_TitleBg] = panel;
  c[ImGuiCol_TitleBgActive] = panel;
  c[ImGuiCol_MenuBarBg] = panel;
  c[ImGuiCol_ScrollbarBg] = bg;
  c[ImGuiCol_ScrollbarGrab] = border;
  c[ImGuiCol_CheckMark] = accent;
  c[ImGuiCol_SliderGrab] = accent;
  c[ImGuiCol_SliderGrabActive] = accent_hover;
  c[ImGuiCol_Button] = frame;
  c[ImGuiCol_ButtonHovered] = ImVec4(accent.x, accent.y, accent.z, 0.55f);
  c[ImGuiCol_ButtonActive] = accent;
  c[ImGuiCol_Header] = ImVec4(accent.x, accent.y, accent.z, 0.28f);
  c[ImGuiCol_HeaderHovered] = ImVec4(accent.x, accent.y, accent.z, 0.46f);
  c[ImGuiCol_HeaderActive] = ImVec4(accent.x, accent.y, accent.z, 0.68f);
  c[ImGuiCol_Separator] = border;
  c[ImGuiCol_SeparatorHovered] = accent_hover;
  c[ImGuiCol_SeparatorActive] = accent;
  c[ImGuiCol_ResizeGrip] = ImVec4(accent.x, accent.y, accent.z, 0.25f);
  c[ImGuiCol_ResizeGripHovered] = ImVec4(accent.x, accent.y, accent.z, 0.55f);
  c[ImGuiCol_ResizeGripActive] = accent;
  c[ImGuiCol_Tab] = frame;
  c[ImGuiCol_TabHovered] = ImVec4(accent.x, accent.y, accent.z, 0.48f);
  c[ImGuiCol_TabSelected] = ImVec4(accent.x, accent.y, accent.z, 0.35f);
  c[ImGuiCol_NavHighlight] = accent;
}

void Render() {
  const ImGuiViewport* viewport = ImGui::GetMainViewport();
  const ImVec2 work = viewport->WorkSize;
  const float panel_width = std::clamp(work.x - 64.0f, 720.0f, 1180.0f);
  const float panel_height = std::clamp(work.y - 64.0f, 560.0f, 720.0f);
  ImGui::SetNextWindowPos(ImVec2(viewport->WorkPos.x + (work.x - panel_width) * 0.5f, viewport->WorkPos.y + (work.y - panel_height) * 0.5f), ImGuiCond_Always);
  ImGui::SetNextWindowSize(ImVec2(panel_width, panel_height), ImGuiCond_Always);

  constexpr ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoTitleBar;
  if (!ImGui::Begin("Control Panel", nullptr, flags)) {
    ImGui::End();
    return;
  }

  const float nav_width = state.nav_collapsed ? 58.0f : 112.0f;
  const float toolbar_height = 42.0f;
  ImGui::BeginChild("workspace", ImVec2(-(nav_width + 10.0f), 0), ImGuiChildFlags_Borders);
  ImGui::AlignTextToFramePadding();
  ImGui::TextUnformatted("CONTROL PANEL");
  ImGui::SameLine();
  ImGui::SetCursorPosX(ImGui::GetWindowWidth() - 205.0f);
  ImGui::SetNextItemWidth(145.0f);
  int previous_theme = state.theme;
  ImGui::Combo("##theme", &state.theme, kThemes, IM_ARRAYSIZE(kThemes));
  if (previous_theme != state.theme) ApplyTheme(state.theme);
  ImGui::SameLine();
  if (ImGui::Button("Reset", ImVec2(50.0f, 0))) {
    state = State{};
    ApplyTheme(state.theme);
  }
  ImGui::Separator();
  ImGui::BeginChild("content", ImVec2(0, -(toolbar_height + 6.0f)), ImGuiChildFlags_None, ImGuiWindowFlags_AlwaysVerticalScrollbar);
  DrawContent();
  ImGui::EndChild();
  ImGui::Separator();
  ImGui::TextDisabled("Ready  |  Theme: %s", kThemes[state.theme]);
  ImGui::EndChild();

  ImGui::SameLine();
  ImGui::BeginChild("navigation", ImVec2(nav_width, 0), ImGuiChildFlags_Borders);
  if (ImGui::Button(state.nav_collapsed ? ">>" : "<< Collapse", ImVec2(-1, 32))) state.nav_collapsed = !state.nav_collapsed;
  NavButton("[+]", "AIMBOT", Tab::Aimbot, -1.0f);
  NavButton("[o]", "VISUALS", Tab::Visuals, -1.0f);
  NavButton("[x]", "LOOT", Tab::Loot, -1.0f);
  NavButton("</>", "SCRIPTS", Tab::Scripts, -1.0f);
  ImGui::EndChild();
  ImGui::End();
}

}  // namespace control_panel
