# Dear ImGui Control Panel

A standalone C++17 port of the supplied control-panel interface. It includes four themes, functional tabs, checkboxes, combo boxes, sliders, a collapsible navigation rail, and DPI-aware sizing.

## Build

Requirements: CMake 3.20+, a C++17 compiler, Git, and OpenGL development libraries.

```bash
cmake -S . -B build
cmake --build build --config Release
```

CMake downloads pinned Dear ImGui and GLFW releases during configuration. Run `imgui-control-panel` from the build directory.

## Integration

`src/control_panel.cpp` only depends on Dear ImGui. Copy `control_panel.h/.cpp` into an existing ImGui project and call:

```cpp
control_panel::Render();
```

The demo in `src/main.cpp` provides the GLFW/OpenGL host window.
